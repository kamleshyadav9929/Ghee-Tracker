
import React from 'react';
import { useLocation } from 'react-router-dom';
import ThemeToggle from './ThemeToggle';

interface HeaderProps {
  toggleSidebar: () => void;
  toggleTheme: () => void;
  currentTheme: string;
}

const MenuIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />
  </svg>
);

const Header: React.FC<HeaderProps> = ({ toggleSidebar, toggleTheme, currentTheme }) => {
    const location = useLocation();
    const getTitle = () => {
        const path = location.pathname.split('/')[1];
        if (!path || path === 'dashboard') return 'Dashboard';
        return path.charAt(0).toUpperCase() + path.slice(1);
    }
  return (
    <header className="flex justify-between items-center p-4 bg-white dark:bg-gray-800 shadow-md">
      <div className="flex items-center">
        <button onClick={toggleSidebar} className="text-gray-500 dark:text-gray-400 focus:outline-none lg:hidden">
          <MenuIcon className="h-6 w-6" />
        </button>
        <h1 className="text-2xl font-semibold text-gray-800 dark:text-white ml-4">{getTitle()}</h1>
      </div>
      <div className="flex items-center space-x-4">
        <ThemeToggle toggleTheme={toggleTheme} currentTheme={currentTheme} />
      </div>
    </header>
  );
};

export default Header;
