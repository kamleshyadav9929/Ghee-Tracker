
import React from 'react';
import { NavLink } from 'react-router-dom';

const DashboardIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
  </svg>
);

const CustomerIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.25-1.26-.695-1.724M17 20V10a4 4 0 00-8 0v10h10zm-6-2h2m-4 0h.01M12 6a2 2 0 110 4 2 2 0 010-4z" />
  </svg>
);

const OrderIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
  </svg>
);

const ReportIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
  </svg>
);

const SettingsIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);

const GheeIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M12 3C9.23858 3 7 5.23858 7 8V14C7 17.3137 9.68629 20 13 20H15C18.3137 20 21 17.3137 21 14V8C21 5.23858 18.7614 3 16 3H12Z" stroke="currentColor" strokeWidth="1.5"/>
        <path d="M7 10H3C2.44772 10 2 10.4477 2 11V13C2 13.5523 2.44772 14 3 14H7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
        <path d="M16 3C16 1.89543 16.8954 1 18 1C19.1046 1 20 1.89543 20 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
);

interface SidebarProps {
  isOpen: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen }) => {
  const navLinkClass = "flex items-center mt-4 py-2 px-6 rounded-md text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 hover:text-gray-700 dark:hover:text-gray-200";
  const activeLinkClass = "bg-primary-100 dark:bg-primary-900 text-primary-700 dark:text-primary-200";

  return (
    <aside className={`relative bg-white dark:bg-gray-800 shadow-xl h-screen overflow-hidden ${isOpen ? 'w-64' : 'w-0'} transition-all duration-300 ease-in-out lg:w-64 lg:static`}>
      <div className="flex items-center justify-center mt-8">
         <GheeIcon className="w-10 h-10 text-primary-500"/>
        <span className="text-gray-800 dark:text-white text-2xl font-semibold ml-2">Ghee.ly</span>
      </div>
      <nav className="mt-10 px-2">
        <NavLink to="/dashboard" className={({ isActive }) => `${navLinkClass} ${isActive ? activeLinkClass : ''}`}>
          <DashboardIcon className="h-6 w-6" />
          <span className="mx-3">Dashboard</span>
        </NavLink>
        <NavLink to="/customers" className={({ isActive }) => `${navLinkClass} ${isActive ? activeLinkClass : ''}`}>
          <CustomerIcon className="h-6 w-6" />
          <span className="mx-3">Customers</span>
        </NavLink>
        <NavLink to="/orders" className={({ isActive }) => `${navLinkClass} ${isActive ? activeLinkClass : ''}`}>
          <OrderIcon className="h-6 w-6" />
          <span className="mx-3">Orders</span>
        </NavLink>
        <NavLink to="/reports" className={({ isActive }) => `${navLinkClass} ${isActive ? activeLinkClass : ''}`}>
          <ReportIcon className="h-6 w-6" />
          <span className="mx-3">Reports</span>
        </NavLink>
        <NavLink to="/settings" className={({ isActive }) => `${navLinkClass} ${isActive ? activeLinkClass : ''}`}>
          <SettingsIcon className="h-6 w-6" />
          <span className="mx-3">Settings</span>
        </NavLink>
      </nav>
    </aside>
  );
};

export default Sidebar;
