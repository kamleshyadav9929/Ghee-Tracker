
import React, { createContext, useReducer, useContext, ReactNode, useMemo } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { Customer, Order, Payment, PaymentStatus } from '../types';

interface AppState {
  customers: Customer[];
  orders: Order[];
}

type Action =
  | { type: 'ADD_CUSTOMER'; payload: Customer }
  | { type: 'UPDATE_CUSTOMER'; payload: Customer }
  | { type: 'DELETE_CUSTOMER'; payload: string } // id
  | { type: 'ADD_ORDER'; payload: Order }
  | { type: 'UPDATE_ORDER'; payload: Order }
  | { type: 'DELETE_ORDER'; payload: string } // id
  | { type: 'ADD_PAYMENT'; payload: { orderId: string; payment: Payment } }
  | { type: 'SET_STATE'; payload: AppState };

const initialState: AppState = {
  customers: [],
  orders: [],
};

const AppReducer = (state: AppState, action: Action): AppState => {
  switch (action.type) {
    case 'ADD_CUSTOMER':
      return { ...state, customers: [...state.customers, action.payload] };
    case 'UPDATE_CUSTOMER':
      return {
        ...state,
        customers: state.customers.map(c => c.id === action.payload.id ? action.payload : c),
      };
    case 'DELETE_CUSTOMER':
      return {
        ...state,
        customers: state.customers.filter(c => c.id !== action.payload),
        orders: state.orders.filter(o => o.customerId !== action.payload),
      };
    case 'ADD_ORDER':
      return { ...state, orders: [...state.orders, action.payload] };
    case 'UPDATE_ORDER': {
      const updatedOrders = state.orders.map(o => o.id === action.payload.id ? action.payload : o);
      return { ...state, orders: updatedOrders };
    }
    case 'DELETE_ORDER':
      return {
        ...state,
        orders: state.orders.filter(o => o.id !== action.payload),
      };
    case 'ADD_PAYMENT': {
      const updatedOrders = state.orders.map(order => {
        if (order.id === action.payload.orderId) {
          const newPayments = [...order.payments, action.payload.payment];
          const totalPaid = newPayments.reduce((acc, p) => acc + p.amount, 0);
          let newStatus = PaymentStatus.Partial;
          if (totalPaid >= order.totalPrice) {
            newStatus = PaymentStatus.Paid;
          } else if (totalPaid === 0) {
            newStatus = PaymentStatus.Pending;
          }
          return { ...order, payments: newPayments, paymentStatus: newStatus };
        }
        return order;
      });
      return { ...state, orders: updatedOrders };
    }
    case 'SET_STATE':
        return action.payload;
    default:
      return state;
  }
};

const AppContext = createContext<{ state: AppState; dispatch: React.Dispatch<Action>, customerSummaries: any[] }>({
  state: initialState,
  dispatch: () => null,
  customerSummaries: [],
});

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [persistedState, setPersistedState] = useLocalStorage<AppState>('ghee-business-data', initialState);
  
  const reducer = (state: AppState, action: Action) => {
    const newState = AppReducer(state, action);
    setPersistedState(newState);
    return newState;
  };
  
  const [state, dispatch] = useReducer(reducer, persistedState);
  
  const customerSummaries = useMemo(() => {
    return state.customers.map(customer => {
        const customerOrders = state.orders.filter(o => o.customerId === customer.id);
        const totalAmount = customerOrders.reduce((sum, order) => sum + order.totalPrice, 0);
        const totalPaid = customerOrders.reduce((sum, order) => sum + order.payments.reduce((pSum, p) => pSum + p.amount, 0), 0);
        const pendingBalance = totalAmount - totalPaid;
        return {
            ...customer,
            totalAmount,
            totalPaid,
            pendingBalance
        };
    });
  }, [state.customers, state.orders]);


  return (
    <AppContext.Provider value={{ state, dispatch, customerSummaries }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => useContext(AppContext);
