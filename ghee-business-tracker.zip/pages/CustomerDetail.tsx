import React, { useState, useMemo } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { Order, Payment, PaymentStatus } from '../types';
import Modal from '../components/Modal';
import CustomerForm from '../components/CustomerForm';

const PlusIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" /></svg>
);
const BackIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
);
const EditIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
    </svg>
);
const TrashIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
);


const OrderForm: React.FC<{ onSave: (order: Omit<Order, 'id' | 'payments' | 'paymentStatus'>) => void; onClose: () => void; customerId: string }> = ({ onSave, onClose, customerId }) => {
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [quantity, setQuantity] = useState(1);
    const [unit, setUnit] = useState<'kg' | 'liter'>('kg');
    const [pricePerUnit, setPricePerUnit] = useState(0);
    const [notes, setNotes] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ customerId, date, quantity, unit, pricePerUnit, totalPrice: quantity * pricePerUnit, notes });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label className="block mb-2 text-sm font-medium">Date</label>
                <input type="date" value={date} onChange={e => setDate(e.target.value)} className="input-field" required />
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block mb-2 text-sm font-medium">Quantity</label>
                    <input type="number" value={quantity} onChange={e => setQuantity(Number(e.target.value))} min="0" step="0.01" className="input-field" required />
                </div>
                <div>
                    <label className="block mb-2 text-sm font-medium">Unit</label>
                    <select value={unit} onChange={e => setUnit(e.target.value as 'kg' | 'liter')} className="input-field">
                        <option value="kg">kg</option>
                        <option value="liter">liter</option>
                    </select>
                </div>
            </div>
            <div>
                <label className="block mb-2 text-sm font-medium">Price per {unit}</label>
                <input type="number" value={pricePerUnit} onChange={e => setPricePerUnit(Number(e.target.value))} min="0" step="0.01" className="input-field" required />
            </div>
            <div>
                <label className="block mb-2 text-sm font-medium">Total Price</label>
                <input type="text" value={(quantity * pricePerUnit).toFixed(2)} className="input-field bg-gray-200 dark:bg-gray-600" readOnly />
            </div>
            <div>
                <label className="block mb-2 text-sm font-medium">Notes (Optional)</label>
                <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} className="input-field"></textarea>
            </div>
            <div className="mt-6 flex justify-end space-x-3">
                <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
                <button type="submit" className="btn-primary">Save Order</button>
            </div>
        </form>
    );
};

const PaymentForm: React.FC<{ onSave: (payment: Omit<Payment, 'id'>) => void; onClose: () => void; order: Order }> = ({ onSave, onClose, order }) => {
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const totalPaid = order.payments.reduce((sum, p) => sum + p.amount, 0);
    const remaining = order.totalPrice - totalPaid;
    const [amount, setAmount] = useState<number>(remaining);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ date, amount });
    };

    return (
         <form onSubmit={handleSubmit} className="space-y-4">
            <p>Order Total: {order.totalPrice.toFixed(2)}</p>
            <p className="text-green-500">Paid: {totalPaid.toFixed(2)}</p>
            <p className="text-red-500">Remaining: {remaining.toFixed(2)}</p>
            <div>
                <label className="block mb-2 text-sm font-medium">Payment Date</label>
                <input type="date" value={date} onChange={e => setDate(e.target.value)} className="input-field" required />
            </div>
            <div>
                <label className="block mb-2 text-sm font-medium">Amount</label>
                <input type="number" value={amount} onChange={e => setAmount(Number(e.target.value))} max={remaining} min="0.01" step="0.01" className="input-field" required />
            </div>
            <div className="mt-6 flex justify-end space-x-3">
                <button type="button" onClick={onClose} className="btn-secondary">Cancel</button>
                <button type="submit" className="btn-primary">Add Payment</button>
            </div>
        </form>
    );
};

const CustomerDetail: React.FC = () => {
  const { customerId } = useParams<{ customerId: string }>();
  const { state, dispatch, customerSummaries } = useAppContext();
  const navigate = useNavigate();

  const [isOrderModalOpen, setOrderModalOpen] = useState(false);
  const [isPaymentModalOpen, setPaymentModalOpen] = useState(false);
  const [isEditModalOpen, setEditModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const customerSummary = useMemo(() => {
    return customerSummaries.find(c => c.id === customerId);
  }, [customerSummaries, customerId]);

  const customerOrders = useMemo(() => {
    return state.orders
        .filter(o => o.customerId === customerId)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [state.orders, customerId]);
  
  const formatCurrency = (amount: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);

  if (!customerSummary) {
    return <div className="text-center p-8">Customer not found. <Link to="/customers" className="text-primary-500">Go back</Link></div>;
  }
  
  const handleAddOrder = (orderData: Omit<Order, 'id'|'payments'|'paymentStatus'>) => {
    const newOrder: Order = {
        ...orderData,
        id: crypto.randomUUID(),
        payments: [],
        paymentStatus: orderData.totalPrice > 0 ? PaymentStatus.Pending : PaymentStatus.Paid,
    };
    dispatch({ type: 'ADD_ORDER', payload: newOrder });
    setOrderModalOpen(false);
  };
  
  const handleAddPayment = (paymentData: Omit<Payment, 'id'>) => {
    if (selectedOrder) {
        dispatch({ type: 'ADD_PAYMENT', payload: { orderId: selectedOrder.id, payment: {...paymentData, id: crypto.randomUUID()}}});
    }
    setPaymentModalOpen(false);
    setSelectedOrder(null);
  }

  const handleUpdateCustomer = (data: { name: string; phone: string; address: string; }) => {
    if (customerId) {
        dispatch({ type: 'UPDATE_CUSTOMER', payload: { ...data, id: customerId } });
    }
    setEditModalOpen(false);
  }

  const handleDeleteCustomer = () => {
    if (customerId && window.confirm("Are you sure you want to delete this customer? This will also delete all their associated orders. This action cannot be undone.")) {
        dispatch({ type: 'DELETE_CUSTOMER', payload: customerId });
        navigate('/customers');
    }
  }
  
  const handleDeleteOrder = (orderId: string) => {
    if (window.confirm("Are you sure you want to delete this order? This action cannot be undone.")) {
        dispatch({ type: 'DELETE_ORDER', payload: orderId });
    }
  }
  
  const openPaymentModal = (order: Order) => {
    setSelectedOrder(order);
    setPaymentModalOpen(true);
  }

  return (
    <>
      <style>{`
        .input-field {
            @apply bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-primary-500 focus:border-primary-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500;
        }
        .btn-primary {
            @apply py-2 px-4 text-sm font-medium text-white bg-primary-600 rounded-lg hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800;
        }
        .btn-secondary {
            @apply py-2 px-4 text-sm font-medium text-gray-700 bg-white rounded-lg border border-gray-200 hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-primary-300 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600;
        }
      `}</style>
      <button onClick={() => navigate(-1)} className="flex items-center text-sm text-gray-600 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 mb-4">
        <BackIcon className="w-5 h-5 mr-2" />
        Back to Customers
      </button>

      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md mb-6">
        <div className="flex flex-col md:flex-row justify-between items-start">
            <div>
                <div className="flex items-center gap-4">
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{customerSummary.name}</h2>
                    <div className="flex items-center gap-2">
                        <button onClick={() => setEditModalOpen(true)} className="p-1 text-gray-500 hover:text-primary-600 dark:text-gray-400 dark:hover:text-primary-400" aria-label="Edit customer">
                            <EditIcon className="w-5 h-5"/>
                        </button>
                        <button onClick={handleDeleteCustomer} className="p-1 text-gray-500 hover:text-red-600 dark:text-gray-400 dark:hover:text-red-500" aria-label="Delete customer">
                            <TrashIcon className="w-5 h-5"/>
                        </button>
                    </div>
                </div>
                <p className="text-gray-500 dark:text-gray-400 mt-1">{customerSummary.phone}</p>
                <p className="text-gray-500 dark:text-gray-400">{customerSummary.address}</p>
            </div>
            <div className="text-left md:text-right mt-4 md:mt-0">
                <p className="text-sm text-gray-500 dark:text-gray-400">Total Billed: <span className="font-semibold text-lg text-gray-800 dark:text-gray-200">{formatCurrency(customerSummary.totalAmount)}</span></p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Total Paid: <span className="font-semibold text-lg text-green-600 dark:text-green-400">{formatCurrency(customerSummary.totalPaid)}</span></p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Balance: <span className="font-bold text-xl text-red-600 dark:text-red-400">{formatCurrency(customerSummary.pendingBalance)}</span></p>
            </div>
        </div>
      </div>

      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-semibold">Order History</h3>
        <button onClick={() => setOrderModalOpen(true)} className="btn-primary flex items-center">
          <PlusIcon className="w-5 h-5 mr-2" />
          New Order
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
             <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
              <tr>
                <th scope="col" className="px-6 py-3">Date</th>
                <th scope="col" className="px-6 py-3">Details</th>
                <th scope="col" className="px-6 py-3">Total</th>
                <th scope="col" className="px-6 py-3">Paid</th>
                <th scope="col" className="px-6 py-3">Status</th>
                <th scope="col" className="px-6 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {customerOrders.length > 0 ? customerOrders.map(order => {
                  const totalPaid = order.payments.reduce((sum, p) => sum + p.amount, 0);
                  return (
                    <tr key={order.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                        <td className="px-6 py-4">{new Date(order.date).toLocaleDateString()}</td>
                        <td className="px-6 py-4">{order.quantity} {order.unit} @ {formatCurrency(order.pricePerUnit)}</td>
                        <td className="px-6 py-4">{formatCurrency(order.totalPrice)}</td>
                        <td className="px-6 py-4 text-green-600 dark:text-green-400">{formatCurrency(totalPaid)}</td>
                        <td className="px-6 py-4">
                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                order.paymentStatus === PaymentStatus.Paid ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' :
                                order.paymentStatus === PaymentStatus.Partial ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300' :
                                'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
                            }`}>
                                {order.paymentStatus}
                            </span>
                        </td>
                        <td className="px-6 py-4">
                            <div className="flex items-center space-x-4">
                                {order.paymentStatus !== PaymentStatus.Paid && (
                                    <button onClick={() => openPaymentModal(order)} className="font-medium text-primary-600 dark:text-primary-500 hover:underline">Add Payment</button>
                                )}
                                <button onClick={() => handleDeleteOrder(order.id)} className="text-red-600 hover:text-red-800 dark:text-red-500 dark:hover:text-red-400" aria-label="Delete order">
                                    <TrashIcon className="w-5 h-5" />
                                </button>
                            </div>
                        </td>
                    </tr>
                  )
              }) : (
                <tr><td colSpan={6} className="text-center py-8">No orders found for this customer.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      <Modal isOpen={isOrderModalOpen} onClose={() => setOrderModalOpen(false)} title="Add New Order">
        <OrderForm customerId={customerSummary.id} onSave={handleAddOrder} onClose={() => setOrderModalOpen(false)} />
      </Modal>

      <Modal isOpen={isEditModalOpen} onClose={() => setEditModalOpen(false)} title="Edit Customer">
        <CustomerForm 
            initialData={customerSummary}
            onSave={handleUpdateCustomer} 
            onClose={() => setEditModalOpen(false)} 
        />
      </Modal>
      
      {selectedOrder && (
         <Modal isOpen={isPaymentModalOpen} onClose={() => setPaymentModalOpen(false)} title={`Add Payment for Order`}>
           <PaymentForm order={selectedOrder} onSave={handleAddPayment} onClose={() => setPaymentModalOpen(false)} />
         </Modal>
      )}

    </>
  );
};

export default CustomerDetail;