import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import Modal from '../components/Modal';
import { Link } from 'react-router-dom';
import CustomerForm from '../components/CustomerForm';

const PlusIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
    </svg>
);

const SearchIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" >
        <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
    </svg>
);

const TrashIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
    </svg>
);

const Customers: React.FC = () => {
  const { customerSummaries, dispatch } = useAppContext();
  const [isModalOpen, setModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  const formatCurrency = (amount: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);

  const handleAddCustomer = (data: { name: string; phone: string; address: string; }) => {
    dispatch({ type: 'ADD_CUSTOMER', payload: { ...data, id: crypto.randomUUID() } });
    setModalOpen(false);
  };

  const handleDeleteCustomer = (customerId: string) => {
    if (window.confirm("Are you sure you want to delete this customer? All their orders and payments will be deleted as well. This action cannot be undone.")) {
        dispatch({ type: 'DELETE_CUSTOMER', payload: customerId });
    }
  }

  const filteredCustomers = useMemo(() => {
    return customerSummaries.filter(customer =>
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.phone.includes(searchTerm)
    );
  }, [customerSummaries, searchTerm]);

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <div className="relative w-full max-w-sm">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <SearchIcon className="w-5 h-5 text-gray-500 dark:text-gray-400"/>
            </div>
            <input
            type="text"
            placeholder="Search by name or phone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="block w-full p-2.5 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-primary-500 focus:border-primary-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-primary-500 dark:focus:border-primary-500"
            />
        </div>
        <button onClick={() => setModalOpen(true)} className="flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-primary-600 rounded-lg hover:bg-primary-700 focus:ring-4 focus:outline-none focus:ring-primary-300 dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800">
          <PlusIcon className="w-5 h-5 mr-2" />
          Add Customer
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
              <tr>
                <th scope="col" className="px-6 py-3">Name</th>
                <th scope="col" className="px-6 py-3">Phone</th>
                <th scope="col" className="px-6 py-3">Total Billed</th>
                <th scope="col" className="px-6 py-3">Total Paid</th>
                <th scope="col" className="px-6 py-3">Pending Balance</th>
                <th scope="col" className="px-6 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.length > 0 ? filteredCustomers.map(customer => (
                <tr key={customer.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                  <th scope="row" className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                    <Link to={`/customers/${customer.id}`} className="hover:text-primary-600 dark:hover:text-primary-400">{customer.name}</Link>
                  </th>
                  <td className="px-6 py-4">{customer.phone}</td>
                  <td className="px-6 py-4">{formatCurrency(customer.totalAmount)}</td>
                  <td className="px-6 py-4 text-green-600 dark:text-green-400">{formatCurrency(customer.totalPaid)}</td>
                  <td className={`px-6 py-4 font-bold ${customer.pendingBalance > 0 ? 'text-red-600 dark:text-red-400' : ''}`}>
                    {formatCurrency(customer.pendingBalance)}
                  </td>
                  <td className="px-6 py-4">
                    <button onClick={() => handleDeleteCustomer(customer.id)} className="text-red-600 hover:text-red-800 dark:text-red-500 dark:hover:text-red-400" aria-label="Delete customer">
                        <TrashIcon className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                    <td colSpan={6} className="text-center py-8 text-gray-500">
                        {customerSummaries.length === 0 ? "No customers yet. Click 'Add Customer' to start." : "No customers found for your search."}
                    </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setModalOpen(false)} title="Add New Customer">
        <CustomerForm onSave={handleAddCustomer} onClose={() => setModalOpen(false)} />
      </Modal>
    </>
  );
};

export default Customers;