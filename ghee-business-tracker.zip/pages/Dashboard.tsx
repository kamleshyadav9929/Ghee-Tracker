
import React, { useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { Order, PaymentStatus } from '../types';
import { Link } from 'react-router-dom';

const StatCard: React.FC<{ title: string; value: string | number; icon: React.ReactNode; color: string }> = ({ title, value, icon, color }) => (
  <div className={`bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md flex items-center justify-between`}>
    <div>
      <p className="text-sm font-medium text-gray-500 dark:text-gray-400 uppercase">{title}</p>
      <p className="text-2xl font-bold text-gray-900 dark:text-white">{value}</p>
    </div>
    <div className={`p-3 rounded-full ${color}`}>
      {icon}
    </div>
  </div>
);

const SalesIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
);
const PaidIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v.01" /></svg>
);
const PendingIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);
const CustomerIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.653-.25-1.26-.695-1.724M17 20V10a4 4 0 00-8 0v10h10zm-6-2h2m-4 0h.01M12 6a2 2 0 110 4 2 2 0 010-4z" /></svg>
);

const Dashboard: React.FC = () => {
  const { state, customerSummaries } = useAppContext();

  const dashboardStats = useMemo(() => {
    const totalSales = state.orders.reduce((acc, order) => acc + order.totalPrice, 0);
    const totalPaid = state.orders.reduce((acc, order) => acc + order.payments.reduce((pAcc, p) => pAcc + p.amount, 0), 0);
    const pendingAmount = totalSales - totalPaid;
    const totalCustomers = state.customers.length;
    return { totalSales, totalPaid, pendingAmount, totalCustomers };
  }, [state.orders, state.customers]);

  const recentOrders = useMemo(() => {
    return [...state.orders]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 5);
  }, [state.orders]);

  const topCustomersByBalance = useMemo(() => {
    return [...customerSummaries]
      .filter(c => c.pendingBalance > 0)
      .sort((a, b) => b.pendingBalance - a.pendingBalance)
      .slice(0, 5);
  }, [customerSummaries]);

  const getCustomerName = (customerId: string) => {
    return state.customers.find(c => c.id === customerId)?.name || 'Unknown';
  };
  
  const formatCurrency = (amount: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Sales" value={formatCurrency(dashboardStats.totalSales)} icon={<SalesIcon className="h-6 w-6 text-green-600" />} color="bg-green-100" />
        <StatCard title="Total Payments" value={formatCurrency(dashboardStats.totalPaid)} icon={<PaidIcon className="h-6 w-6 text-blue-600" />} color="bg-blue-100" />
        <StatCard title="Pending Amount" value={formatCurrency(dashboardStats.pendingAmount)} icon={<PendingIcon className="h-6 w-6 text-red-600" />} color="bg-red-100" />
        <StatCard title="Total Customers" value={dashboardStats.totalCustomers} icon={<CustomerIcon className="h-6 w-6 text-yellow-600" />} color="bg-yellow-100" />
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Recent Orders</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b dark:border-gray-700">
                  <th className="py-2">Customer</th>
                  <th className="py-2">Amount</th>
                  <th className="py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.length > 0 ? recentOrders.map((order: Order) => (
                  <tr key={order.id} className="border-b dark:border-gray-700 last:border-0">
                    <td className="py-3">{getCustomerName(order.customerId)}</td>
                    <td className="py-3">{formatCurrency(order.totalPrice)}</td>
                    <td className="py-3">
                      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                        order.paymentStatus === PaymentStatus.Paid ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' :
                        order.paymentStatus === PaymentStatus.Partial ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300' :
                        'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
                      }`}>
                        {order.paymentStatus}
                      </span>
                    </td>
                  </tr>
                )) : <tr><td colSpan={3} className="py-4 text-center text-gray-500">No recent orders.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Top Pending Balances</h3>
          <div className="overflow-x-auto">
             <table className="w-full text-left">
              <thead>
                <tr className="border-b dark:border-gray-700">
                  <th className="py-2">Customer</th>
                  <th className="py-2">Balance</th>
                </tr>
              </thead>
              <tbody>
                {topCustomersByBalance.length > 0 ? topCustomersByBalance.map(customer => (
                  <tr key={customer.id} className="border-b dark:border-gray-700 last:border-0">
                    <td className="py-3 hover:text-primary-500"><Link to={`/customers/${customer.id}`}>{customer.name}</Link></td>
                    <td className="py-3 font-medium text-red-500">{formatCurrency(customer.pendingBalance)}</td>
                  </tr>
                )) : <tr><td colSpan={2} className="py-4 text-center text-gray-500">No pending balances.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
