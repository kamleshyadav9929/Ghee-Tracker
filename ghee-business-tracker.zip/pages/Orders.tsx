
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { Order, PaymentStatus } from '../types';
import { Link } from 'react-router-dom';

const Orders: React.FC = () => {
  const { state } = useAppContext();
  const [filterStatus, setFilterStatus] = useState<PaymentStatus | 'all'>('all');
  const [filterCustomer, setFilterCustomer] = useState<string>('all');
  
  const getCustomerName = (customerId: string) => {
    return state.customers.find(c => c.id === customerId)?.name || 'Unknown';
  };
  
  const formatCurrency = (amount: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);

  const filteredOrders = useMemo(() => {
    return state.orders
      .filter(order => filterStatus === 'all' || order.paymentStatus === filterStatus)
      .filter(order => filterCustomer === 'all' || order.customerId === filterCustomer)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [state.orders, filterStatus, filterCustomer]);

  return (
    <>
      <div className="mb-6 p-4 bg-white dark:bg-gray-800 rounded-lg shadow-md flex flex-wrap items-center gap-4">
        <div className="flex-1 min-w-[150px]">
          <label htmlFor="customer-filter" className="text-sm font-medium text-gray-700 dark:text-gray-300">Customer</label>
          <select
            id="customer-filter"
            value={filterCustomer}
            onChange={e => setFilterCustomer(e.target.value)}
            className="mt-1 block w-full p-2 border border-gray-300 bg-white dark:bg-gray-700 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
          >
            <option value="all">All Customers</option>
            {state.customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div className="flex-1 min-w-[150px]">
          <label htmlFor="status-filter" className="text-sm font-medium text-gray-700 dark:text-gray-300">Payment Status</label>
          <select
            id="status-filter"
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value as PaymentStatus | 'all')}
            className="mt-1 block w-full p-2 border border-gray-300 bg-white dark:bg-gray-700 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
          >
            <option value="all">All Statuses</option>
            <option value={PaymentStatus.Paid}>Paid</option>
            <option value={PaymentStatus.Partial}>Partial</option>
            <option value={PaymentStatus.Pending}>Pending</option>
          </select>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
              <tr>
                <th scope="col" className="px-6 py-3">Date</th>
                <th scope="col" className="px-6 py-3">Customer</th>
                <th scope="col" className="px-6 py-3">Total Amount</th>
                <th scope="col" className="px-6 py-3">Amount Paid</th>
                <th scope="col" className="px-6 py-3">Pending</th>
                <th scope="col" className="px-6 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrders.length > 0 ? filteredOrders.map((order: Order) => {
                const totalPaid = order.payments.reduce((sum, p) => sum + p.amount, 0);
                const pending = order.totalPrice - totalPaid;
                return (
                  <tr key={order.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                    <td className="px-6 py-4">{new Date(order.date).toLocaleDateString()}</td>
                    <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">
                      <Link to={`/customers/${order.customerId}`} className="hover:text-primary-600 dark:hover:text-primary-400">
                        {getCustomerName(order.customerId)}
                      </Link>
                    </td>
                    <td className="px-6 py-4">{formatCurrency(order.totalPrice)}</td>
                    <td className="px-6 py-4 text-green-600 dark:text-green-400">{formatCurrency(totalPaid)}</td>
                    <td className={`px-6 py-4 font-bold ${pending > 0 ? 'text-red-600 dark:text-red-400' : ''}`}>{formatCurrency(pending)}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                        order.paymentStatus === PaymentStatus.Paid ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' :
                        order.paymentStatus === PaymentStatus.Partial ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300' :
                        'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
                      }`}>
                        {order.paymentStatus}
                      </span>
                    </td>
                  </tr>
                )
              }) : (
                <tr><td colSpan={6} className="text-center py-8">No orders match the current filters.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

export default Orders;
