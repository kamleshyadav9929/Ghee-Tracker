
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';

const StatCard: React.FC<{ title: string; value: string | number; color?: string }> = ({ title, value, color = 'text-gray-900 dark:text-white' }) => (
  <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
    <p className="text-sm font-medium text-gray-500 dark:text-gray-400 uppercase">{title}</p>
    <p className={`text-3xl font-bold ${color}`}>{value}</p>
  </div>
);


const Reports: React.FC = () => {
  const { state } = useAppContext();
  const today = new Date();
  const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

  const [startDate, setStartDate] = useState(firstDayOfMonth.toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(today.toISOString().split('T')[0]);
  
  const formatCurrency = (amount: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);

  const reportData = useMemo(() => {
    const start = new Date(startDate);
    start.setHours(0, 0, 0, 0);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);

    const ordersInRange = state.orders.filter(order => {
      const orderDate = new Date(order.date);
      return orderDate >= start && orderDate <= end;
    });
    
    const paymentsInRange = state.orders.flatMap(order => order.payments)
      .filter(payment => {
          const paymentDate = new Date(payment.date);
          return paymentDate >= start && paymentDate <= end;
      });

    const totalSales = ordersInRange.reduce((sum, order) => sum + order.totalPrice, 0);
    const totalPaymentsReceived = paymentsInRange.reduce((sum, payment) => sum + payment.amount, 0);
    const totalOrders = ordersInRange.length;
    const totalGheeSold = ordersInRange.reduce((sum, order) => sum + (order.unit === 'kg' ? order.quantity : 0), 0);
    const totalGheeLitersSold = ordersInRange.reduce((sum, order) => sum + (order.unit === 'liter' ? order.quantity : 0), 0);

    return {
      totalSales,
      totalPaymentsReceived,
      totalOrders,
      totalGheeSold,
      totalGheeLitersSold,
      orders: ordersInRange,
    };
  }, [state.orders, startDate, endDate]);

  return (
    <>
      <div className="mb-6 p-4 bg-white dark:bg-gray-800 rounded-lg shadow-md flex flex-wrap items-center gap-4">
        <div>
          <label htmlFor="start-date" className="text-sm font-medium text-gray-700 dark:text-gray-300">Start Date</label>
          <input
            type="date"
            id="start-date"
            value={startDate}
            onChange={e => setStartDate(e.target.value)}
            className="mt-1 block w-full p-2 border border-gray-300 bg-white dark:bg-gray-700 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
          />
        </div>
        <div>
          <label htmlFor="end-date" className="text-sm font-medium text-gray-700 dark:text-gray-300">End Date</label>
          <input
            type="date"
            id="end-date"
            value={endDate}
            onChange={e => setEndDate(e.target.value)}
            className="mt-1 block w-full p-2 border border-gray-300 bg-white dark:bg-gray-700 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
          <StatCard title="Total Sales" value={formatCurrency(reportData.totalSales)} />
          <StatCard title="Payments Received" value={formatCurrency(reportData.totalPaymentsReceived)} color="text-green-600 dark:text-green-400"/>
          <StatCard title="Total Orders" value={reportData.totalOrders} />
          <StatCard title="Ghee Sold (KG)" value={`${reportData.totalGheeSold.toFixed(2)} kg`} />
          <StatCard title="Ghee Sold (Liter)" value={`${reportData.totalGheeLitersSold.toFixed(2)} L`} />
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <h3 className="text-xl font-semibold p-4 border-b dark:border-gray-700">Orders in Period</h3>
        <div className="overflow-x-auto">
           <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
              <tr>
                <th scope="col" className="px-6 py-3">Date</th>
                <th scope="col" className="px-6 py-3">Customer</th>
                <th scope="col" className="px-6 py-3">Amount</th>
                <th scope="col" className="px-6 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
                {reportData.orders.length > 0 ? reportData.orders.map(order => (
                    <tr key={order.id} className="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                        <td className="px-6 py-4">{new Date(order.date).toLocaleDateString()}</td>
                        <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">{state.customers.find(c => c.id === order.customerId)?.name || 'N/A'}</td>
                        <td className="px-6 py-4">{formatCurrency(order.totalPrice)}</td>
                        <td className="px-6 py-4">
                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                                order.paymentStatus === 'Paid' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' :
                                order.paymentStatus === 'Partial' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300' :
                                'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'
                            }`}>{order.paymentStatus}</span>
                        </td>
                    </tr>
                )) : (
                    <tr><td colSpan={4} className="text-center py-8">No orders in the selected date range.</td></tr>
                )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

export default Reports;
