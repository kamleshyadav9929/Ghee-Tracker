
import React, { useRef, useState } from 'react';
import { useAppContext } from '../context/AppContext';

const DownloadIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
);

const UploadIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
    </svg>
);


const Settings: React.FC = () => {
    const { state, dispatch } = useAppContext();
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [feedbackMessage, setFeedbackMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);

    const handleExport = () => {
        try {
            const dataStr = JSON.stringify(state, null, 2);
            const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
            
            const exportFileDefaultName = `ghee-business-backup-${new Date().toISOString().split('T')[0]}.json`;
            
            const linkElement = document.createElement('a');
            linkElement.setAttribute('href', dataUri);
            linkElement.setAttribute('download', exportFileDefaultName);
            linkElement.click();
            setFeedbackMessage({ type: 'success', text: 'Data exported successfully!' });
        } catch (error) {
            console.error("Export failed:", error);
            setFeedbackMessage({ type: 'error', text: 'Failed to export data.' });
        }
        setTimeout(() => setFeedbackMessage(null), 3000);
    };

    const handleImportClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) {
            return;
        }

        if (file.type !== 'application/json') {
            alert('Please select a valid JSON file.');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const text = e.target?.result;
                if (typeof text === 'string') {
                    const importedState = JSON.parse(text);
                    // Basic validation
                    if (importedState.customers && importedState.orders) {
                        if(window.confirm("Are you sure you want to replace all current data with the backup file? This action cannot be undone.")){
                            dispatch({ type: 'SET_STATE', payload: importedState });
                            setFeedbackMessage({ type: 'success', text: 'Data imported successfully!' });
                        }
                    } else {
                        throw new Error("Invalid data structure in JSON file.");
                    }
                }
            } catch (error) {
                 console.error("Import failed:", error);
                 setFeedbackMessage({ type: 'error', text: 'Failed to import data. The file may be corrupt or in the wrong format.' });
            }
            // Reset file input
            if(fileInputRef.current) {
                fileInputRef.current.value = '';
            }
            setTimeout(() => setFeedbackMessage(null), 3000);
        };
        reader.readAsText(file);
    };

    return (
        <div className="max-w-xl mx-auto">
            <h2 className="text-2xl font-bold mb-6">Data Management</h2>

            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Backup & Restore</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
                    Export your app data as a JSON file for backup. You can restore it later by importing the file.
                </p>

                <div className="flex flex-col sm:flex-row gap-4">
                    <button
                        onClick={handleExport}
                        className="flex-1 inline-flex items-center justify-center px-4 py-2.5 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                    >
                       <DownloadIcon className="w-5 h-5 mr-2"/>
                        Export Data
                    </button>
                    <button
                        onClick={handleImportClick}
                        className="flex-1 inline-flex items-center justify-center px-4 py-2.5 text-sm font-medium text-white bg-green-600 rounded-lg hover:bg-green-700 focus:ring-4 focus:outline-none focus:ring-green-300 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800"
                    >
                        <UploadIcon className="w-5 h-5 mr-2"/>
                        Import Data
                    </button>
                    <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileChange}
                        className="hidden"
                        accept="application/json"
                    />
                </div>

                {feedbackMessage && (
                    <div className={`mt-4 p-3 rounded-lg text-sm ${
                        feedbackMessage.type === 'success' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                    }`}>
                        {feedbackMessage.text}
                    </div>
                )}
            </div>

             <div className="bg-red-50 dark:bg-gray-800/50 border border-red-200 dark:border-red-900/50 p-6 rounded-lg shadow-md mt-8">
                <h3 className="text-lg font-semibold text-red-800 dark:text-red-300 mb-2">Danger Zone</h3>
                <p className="text-sm text-red-600 dark:text-red-400 mb-6">
                    These actions are destructive and cannot be undone. Please be certain.
                </p>
                <button
                    onClick={() => {
                        if (window.confirm("ARE YOU ABSOLUTELY SURE? This will delete all customers, orders, and payments permanently.")) {
                           dispatch({ type: 'SET_STATE', payload: { customers: [], orders: [] } });
                           setFeedbackMessage({ type: 'success', text: 'All data has been cleared.' });
                           setTimeout(() => setFeedbackMessage(null), 3000);
                        }
                    }}
                    className="w-full inline-flex items-center justify-center px-4 py-2.5 text-sm font-medium text-white bg-red-600 rounded-lg hover:bg-red-700 focus:ring-4 focus:outline-none focus:ring-red-300 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900"
                >
                    Reset All Data
                </button>
            </div>
        </div>
    );
};

export default Settings;
